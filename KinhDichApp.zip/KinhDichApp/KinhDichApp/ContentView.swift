import SwiftUI

struct ContentView: View {
    var body: some View {
        WebView()
            .ignoresSafeArea(edges: .bottom)
            .background(Color.black)
    }
}

#Preview {
    ContentView()
}
